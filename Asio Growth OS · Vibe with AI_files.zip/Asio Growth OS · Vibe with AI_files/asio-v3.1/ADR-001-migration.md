# ADR-001 · Asio Growth OS — Architecture Decision Record

**Status:** Active  
**Date:** 2025-02  
**Author:** Julián Juárez · UNT TEAM · JAJA.DEV  

---

## Context

The MVP v3.0 is deployed as a single-file HTML artifact on Netlify.
It uses VanillaJS + Chart.js (no React, no build step) with a Neon Postgres
backend via Netlify serverless functions. This document records the migration
path to the production stack once the position is formalized.

---

## Current Stack (MVP v3.0 · Production-ready demo)

| Layer        | Technology                        | Notes                        |
|--------------|-----------------------------------|------------------------------|
| Frontend     | VanillaJS + Chart.js · Single HTML| Zero build step              |
| Hosting      | Netlify (free tier)               | CDN + Edge                   |
| DB           | Neon Postgres via Netlify DB ext  | Serverless PG, auto-pooled   |
| Functions    | Netlify Functions (ESM)           | /api/leads CRUD              |
| Fonts/CDN    | Google Fonts + cdnjs              | No bundle                    |

---

## Target Stack (Post-hire · 3 sprints)

| Layer        | Technology                        | Migration effort             |
|--------------|-----------------------------------|------------------------------|
| Marketing site | Astro 4 (SSG/SSR)              | New project, copy components |
| Dashboard app  | Vite + TypeScript + VanillaJS  | Refactor current JS into TS  |
| Compute-heavy  | Rust → WASM (lead scoring)     | Sprint 3                     |
| DB             | Neon Postgres (stays)          | Same DSN, no migration needed|
| Functions      | Astro API Routes (Netlify adapter)| Re-export same fn logic    |
| CSS            | Vanilla CSS (stays)            | Already modular              |
| Runtime        | Node.js (Netlify Edge Functions) | v20 LTS                    |
| Bundler        | Vite 5                         | Handles WASM imports natively|

---

## Why this path?

### Astro for marketing site
- Ships 0 JS by default → sub-1s LCP vs competitor's React SSR (~4s)
- Island architecture if interactive components needed
- Native image optimization + font optimization
- Same Neon DB accessible via Astro API routes

### Vite + TS for dashboard
- Current VanillaJS is already close to TS-compatible
- Type safety on API responses (leads schema → zod)
- HMR during development

### Rust/WASM for lead scoring
- Current NanoBot is a keyword parser
- Future: scoring algorithm compiled to WASM, called from TS
- No server round-trip for qualification logic

### Neon stays
- Serverless PG is stack-agnostic
- Auto-scales to 0 between sessions (fits SaaS usage patterns)
- Branching feature useful for staging environments

---

## Migration Steps

**Sprint 1 (Week 1–2):** Astro marketing site
1. `npm create astro@latest asio-site`
2. Add Netlify adapter: `npx astro add netlify`
3. Move CSS variables to `src/styles/global.css`
4. Port landing sections as Astro components (`.astro`)
5. Re-use existing Netlify functions as-is
6. Point DNS to new Netlify deploy

**Sprint 2 (Week 3–4):** Vite + TS dashboard
1. `npm create vite@latest asio-dashboard -- --template vanilla-ts`
2. Move dashboard JS → TypeScript, define `Lead`, `LeadStage` types
3. Add zod schema validation on API responses
4. Keep Chart.js (already compatible)
5. Serve dashboard from Astro page or subdomain

**Sprint 3 (Week 5–6):** WASM scoring + polish
1. Write scoring algorithm in Rust (`cargo new lead-scorer --lib`)
2. Compile with `wasm-pack build --target web`
3. Import in Vite TS bundle
4. Replace keyword parser in NanoBot with WASM fn
5. Add Neon DB migration file for scoring fields

---

## What does NOT change

- Neon Postgres schema and DSN
- Netlify Functions contract (`/api/leads` GET/POST/PATCH/DELETE)
- CSS design system (variables, component classes)
- NanoBot UX and reply structure
- Deployment platform (Netlify)

---

## Notes for Asio team handoff

The current `index.html` is fully self-contained and deployable via:
- `netlify deploy --prod --dir .`
- Or Netlify Drop (drag folder to app.netlify.com/drop)
- Or direct file open in browser (offline demo mode, Neon shows offline)

The Netlify Function at `netlify/functions/leads.js` requires `DATABASE_URL`
env var (injected automatically by Netlify DB / Neon extension).

---

*Julián Juárez · UNT TEAM · JAJA.DEV · sistemascancunjefe@gmail.com*
