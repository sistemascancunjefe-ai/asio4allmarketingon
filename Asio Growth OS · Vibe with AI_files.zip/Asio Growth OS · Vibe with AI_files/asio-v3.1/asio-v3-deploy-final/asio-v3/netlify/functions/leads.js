/**
 * ASIO GROWTH OS · Netlify Serverless Function
 * Route: /api/leads (via netlify.toml redirect)
 *
 * Uses Neon HTTP endpoint directly — ZERO npm packages needed.
 * Neon exposes an HTTP SQL endpoint compatible with fetch.
 *
 * Env vars:
 *   DATABASE_URL  → set by Netlify (already injected)
 */

const CORS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

// ── Neon HTTP SQL ─────────────────────────────────────────────────────────────
async function sql(query, params = []) {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) throw new Error("DATABASE_URL not set");

  // Neon HTTP endpoint: https://<host>/sql
  const urlObj = new URL(dbUrl.replace(/^postgres(ql)?:\/\//, "https://"));
  const host = urlObj.hostname;
  const endpoint = `https://${host}/sql`;

  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Neon-Connection-String": dbUrl,
    },
    body: JSON.stringify({ query, params }),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Neon ${res.status}: ${txt}`);
  }

  const data = await res.json();
  return data.rows ?? [];
}

async function initTable() {
  await sql(`CREATE TABLE IF NOT EXISTS leads (
    id      SERIAL PRIMARY KEY,
    name    TEXT NOT NULL,
    company TEXT,
    score   TEXT DEFAULT 'warm',
    amount  TEXT,
    source  TEXT,
    stage   TEXT DEFAULT 'new',
    updated TIMESTAMPTZ DEFAULT NOW()
  )`);
}

// ── Handler ───────────────────────────────────────────────────────────────────
export default async function handler(req) {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

  try {
    await initTable();

    if (req.method === "GET") {
      const rows = await sql(`SELECT * FROM leads ORDER BY updated DESC`);
      const g = { new: [], prog: [], done: [] };
      rows.forEach(r => {
        const stage = r.stage in g ? r.stage : "new";
        g[stage].push({ id: r.id, n: r.name, co: r.company||"", s: r.score||"warm",
          a: r.amount||"", src: r.source||"",
          t: new Date(r.updated).toLocaleTimeString("es-MX",{hour:"2-digit",minute:"2-digit"}) });
      });
      return new Response(JSON.stringify({ ok: true, leads: g }), { status: 200, headers: CORS });
    }

    const body = await req.json().catch(() => ({}));

    if (req.method === "POST") {
      const { n, co="", s="warm", a="", src="", stage="new" } = body;
      if (!n) return new Response(JSON.stringify({ ok: false, error: "name required" }), { status: 400, headers: CORS });
      const rows = await sql(
        `INSERT INTO leads (name,company,score,amount,source,stage) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [n, co, s, a, src, stage]
      );
      return new Response(JSON.stringify({ ok: true, lead: rows[0] }), { status: 201, headers: CORS });
    }

    if (req.method === "PATCH") {
      const { id, stage } = body;
      if (!id || !stage) return new Response(JSON.stringify({ ok: false, error: "id+stage required" }), { status: 400, headers: CORS });
      const rows = await sql(`UPDATE leads SET stage=$1, updated=NOW() WHERE id=$2 RETURNING *`, [stage, id]);
      return new Response(JSON.stringify({ ok: true, lead: rows[0] }), { status: 200, headers: CORS });
    }

    if (req.method === "DELETE") {
      const { id } = body;
      if (!id) return new Response(JSON.stringify({ ok: false, error: "id required" }), { status: 400, headers: CORS });
      await sql(`DELETE FROM leads WHERE id=$1`, [id]);
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers: CORS });
    }

    return new Response(JSON.stringify({ ok: false, error: "method not allowed" }), { status: 405, headers: CORS });

  } catch (err) {
    console.error("leads fn:", err.message);
    return new Response(JSON.stringify({ ok: false, error: err.message }), { status: 500, headers: CORS });
  }
}

export const config = { path: "/api/leads" };
