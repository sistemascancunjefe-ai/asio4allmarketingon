/**
 * ASIO GROWTH OS · Netlify Serverless Function
 * Route: /.netlify/functions/leads
 * DB: Neon Postgres (via netlify db / @neondatabase/serverless)
 *
 * Methods:
 *   GET    → list all leads
 *   POST   → upsert a lead
 *   PATCH  → move lead stage (new → prog → done)
 *   DELETE → remove a lead
 *
 * Env vars required:
 *   DATABASE_URL  → set automatically by `netlify db:create` (Neon extension)
 */

import { neon } from "@neondatabase/serverless";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

// ── DB Bootstrap ──────────────────────────────────────────────────────────────
async function initTable(sql) {
  await sql`
    CREATE TABLE IF NOT EXISTS leads (
      id        SERIAL PRIMARY KEY,
      name      TEXT NOT NULL,
      company   TEXT,
      score     TEXT DEFAULT 'warm',    -- hot | warm | cool
      amount    TEXT,
      source    TEXT,
      stage     TEXT DEFAULT 'new',     -- new | prog | done
      created   TIMESTAMPTZ DEFAULT NOW(),
      updated   TIMESTAMPTZ DEFAULT NOW()
    )
  `;
}

// ── Handler ───────────────────────────────────────────────────────────────────
export default async function handler(req) {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });

  const sql = neon(process.env.DATABASE_URL);
  await initTable(sql);

  try {
    // GET — list all leads grouped by stage
    if (req.method === "GET") {
      const rows = await sql`
        SELECT * FROM leads ORDER BY updated DESC
      `;
      const grouped = { new: [], prog: [], done: [] };
      rows.forEach((r) => {
        const stage = r.stage in grouped ? r.stage : "new";
        grouped[stage].push({
          id: r.id,
          n: r.name,
          co: r.company,
          s: r.score,
          a: r.amount,
          src: r.source,
          t: new Date(r.updated).toLocaleString("es-MX", {
            hour: "2-digit",
            minute: "2-digit",
          }),
        });
      });
      return new Response(JSON.stringify({ ok: true, leads: grouped }), { status: 200, headers });
    }

    const body = await req.json().catch(() => ({}));

    // POST — insert or update lead
    if (req.method === "POST") {
      const { n, co, s = "warm", a, src, stage = "new" } = body;
      if (!n) return new Response(JSON.stringify({ ok: false, error: "name required" }), { status: 400, headers });

      const [row] = await sql`
        INSERT INTO leads (name, company, score, amount, source, stage)
        VALUES (${n}, ${co}, ${s}, ${a}, ${src}, ${stage})
        ON CONFLICT DO NOTHING
        RETURNING *
      `;
      return new Response(JSON.stringify({ ok: true, lead: row }), { status: 201, headers });
    }

    // PATCH — move lead stage
    if (req.method === "PATCH") {
      const { id, stage } = body;
      if (!id || !stage) return new Response(JSON.stringify({ ok: false, error: "id and stage required" }), { status: 400, headers });

      const [row] = await sql`
        UPDATE leads SET stage = ${stage}, updated = NOW()
        WHERE id = ${id}
        RETURNING *
      `;
      return new Response(JSON.stringify({ ok: true, lead: row }), { status: 200, headers });
    }

    // DELETE — remove lead
    if (req.method === "DELETE") {
      const { id } = body;
      if (!id) return new Response(JSON.stringify({ ok: false, error: "id required" }), { status: 400, headers });

      await sql`DELETE FROM leads WHERE id = ${id}`;
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
    }

    return new Response(JSON.stringify({ ok: false, error: "method not allowed" }), { status: 405, headers });
  } catch (err) {
    console.error("leads fn error:", err);
    return new Response(JSON.stringify({ ok: false, error: err.message }), { status: 500, headers });
  }
}

export const config = { path: "/api/leads" };
